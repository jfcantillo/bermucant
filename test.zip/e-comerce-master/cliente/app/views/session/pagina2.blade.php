<?php

	/*echo "Variable local 1 =".$var1;
	echo "<p>"; p salto de linea   el punto es para concatenar*/
	echo "variable sesion 1 = ".Session::get("var1");
	echo "<p>"; /*p salto de linea*/
?>