@extends('templates.maestroinicio')
@section('body')
	<h1>ERROR</h1>

	<h4 style="background: green">La compra no se pudo realizar, contactese con el administrador</h4>

	
@stop