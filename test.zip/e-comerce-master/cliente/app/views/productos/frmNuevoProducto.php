<!DOCTYPE html>
<html>
<head>
	<title> </title>
</head>
<body>

<H1> NUEVO PRODUCTO</H1>

<form action="/productos/guardarproducto"  method="post" > 

<label>codigo</label>
<input type="text" name="codigo">
<p>

<label>nombre</label>
<input type="text" name="nombre">

<p>

<label>categoria</label>
<input type="text" name="categoria">

<p>

<input type="submit" name="guardar" value="Guardar">

</form>



</body>
</html>