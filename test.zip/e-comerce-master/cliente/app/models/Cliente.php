<?php

class Cliente extends Eloquent {
	protected $table = 'clientes';
}
