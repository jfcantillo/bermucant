<?php

class Producto extends Eloquent {

	
	 
	protected $table = 'productos';

	

}
