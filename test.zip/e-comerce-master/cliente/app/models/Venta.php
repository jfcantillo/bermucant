<?php
class Venta extends Eloquent {
	protected $table = 'ventas';
}
