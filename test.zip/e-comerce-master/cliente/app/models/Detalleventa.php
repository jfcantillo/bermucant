<?php
class Detalleventa extends Eloquent {
	protected $table = 'detalle_venta';
}
