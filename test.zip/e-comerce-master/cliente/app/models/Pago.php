<?php

class Pago extends Eloquent {
	protected $table = 'pago';
}
